
# Thibert credentials
KEY: str = 'D399DF17-1991-49FF-8457-F160E1C5319F'
HOST: str = 'https://tapidev.azurewebsites.net'
JSON_URL: str = 'https://tapidev.azurewebsites.net/swagger/V1/swagger.json'

# TaskCreationRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**assigned_group** | **str** |  | [optional] 
**title** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**items** | [**list[TaskItem]**](TaskItem.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


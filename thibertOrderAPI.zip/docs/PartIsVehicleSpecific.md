# PartIsVehicleSpecific

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**thibert_part_number** | **str** | ThibertPartNumber validated | [optional] 
**is_vehicle_specific** | **bool** | Indicates if there is a specific fitment for this part | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


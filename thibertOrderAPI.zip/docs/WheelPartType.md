# WheelPartType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**wheel_part_type_id** | **str** | WheelPartTypeID used to filter result | [optional] 
**wheel_part_types** | [**list[LocalizedString]**](LocalizedString.md) | WheelPartType Name | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


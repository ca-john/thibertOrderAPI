# WheelInstallationKit

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**thibert_part_number** | **str** | Thibert part number associated with this part. | [optional] 
**part** | [**Part**](Part.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# Taxline

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tax_id** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**percentage** | **float** |  | [optional] 
**amount** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# OrderTracking

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**thibert_order_number** | **str** |  | [optional] 
**web_order_reference** | **str** |  | [optional] 
**tracking_number** | **str** |  | [optional] 
**tracking_url** | **str** |  | [optional] 
**carrier** | **str** |  | [optional] 
**thibert_part_number** | **str** |  | [optional] 
**shiped_quantity** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


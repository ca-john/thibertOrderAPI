# PartInventory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**thibert_part_number** | **str** | Thibert part number associated with this item. | [optional] 
**inventories** | [**list[Inventory]**](Inventory.md) | List of all inventories associated with this item. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


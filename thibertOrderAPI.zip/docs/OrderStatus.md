# OrderStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**thibert_order_number** | **str** | Indicates the Thibert Order Number | [optional] 
**order_reference_number** | **str** | Client order number reference. | [optional] 
**status** | **str** | Indicates the Thibert status of the order | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


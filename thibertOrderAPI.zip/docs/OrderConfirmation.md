# OrderConfirmation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**order_number** | **str** | Internal identifier for the order. | [optional] 
**creation_date** | **datetime** | Date when the order was processed. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# WheelInstallation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**thibert_part_number** | **str** | Thibert part number | [optional] 
**wheel_installation_kits** | [**list[WheelInstallationKit]**](WheelInstallationKit.md) |  | [optional] 
**wheel_installation_parts** | [**list[WheelInstallationPart]**](WheelInstallationPart.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


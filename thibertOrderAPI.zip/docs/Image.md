# Image

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**thibert_part_number** | **str** | Part number of the item associated with this image. | [optional] 
**image_url** | **str** | URL of where the image is hosted and can be retrived. | [optional] 
**image_type** | **str** | Type of the image. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

